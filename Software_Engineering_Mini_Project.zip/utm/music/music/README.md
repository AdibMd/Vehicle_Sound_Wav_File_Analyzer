# djangomusicplayer
This is a music player made using Django and HTML5.
