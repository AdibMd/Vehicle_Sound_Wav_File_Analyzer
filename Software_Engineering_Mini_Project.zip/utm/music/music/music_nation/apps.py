from django.apps import AppConfig


class MusicNationConfig(AppConfig):
    name = 'music_nation'
