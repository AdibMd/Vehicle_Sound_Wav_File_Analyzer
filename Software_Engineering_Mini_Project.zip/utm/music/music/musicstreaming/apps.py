from django.apps import AppConfig


class MusicstreamingConfig(AppConfig):
    name = 'musicstreaming'
